"""Resmokeconfig module."""
from __future__ import absolute_import

from .suites import NAMED_SUITES
from .loggers import NAMED_LOGGERS
